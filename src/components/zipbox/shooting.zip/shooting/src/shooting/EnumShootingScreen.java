package shooting;

public enum EnumShootingScreen {
	START,
	GAME,
	GAME_OVER,
}
