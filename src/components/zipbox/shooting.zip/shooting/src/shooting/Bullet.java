package shooting;

public class Bullet {
	public int x,y;
	public Bullet() {

	}
	public Bullet(int x,int y) {
		this.x=x;
		this.y=y;
	}
}
